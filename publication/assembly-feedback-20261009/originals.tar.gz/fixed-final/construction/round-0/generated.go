package main

//gooo:generated:start id="urn:gooo:assembly-feedback:label" kind="entity"
type GoooRecordd44c4eec0d13f2410ad9e86a992bd724149f3016474ab0fba8c9be59d3ebaf91 struct {
	GoooFieldffd19ac5a7759ee3060bf3a50a37f6177f0970c00343fd0b09c17e9738ec2dcc string `json:"text"`
	GoooField30255b9c0ed5c552cc79a7345427c565ae7df33e1fb666c7c5a54753c93c5de9 bool   `json:"active"`
	GoooField0959ac3ccc504b2888464eb8dd343c42dc7076cd58e1700486b97e1c9d89f89a int64  `json:"count"`
}

//gooo:generated:end id="urn:gooo:assembly-feedback:label" kind="entity"

//gooo:generated:start id="urn:gooo:assembly-feedback:describe" kind="activity"
func GoooComposedActivity0(input0 int64, input1 bool, input2 string) GoooRecordd44c4eec0d13f2410ad9e86a992bd724149f3016474ab0fba8c9be59d3ebaf91 {
	var text = input2
	var active = input1 && input0 > 0
	_ = active
	if input1 && input0 > 0 {
		text = text + "!"
	}
	return GoooRecordd44c4eec0d13f2410ad9e86a992bd724149f3016474ab0fba8c9be59d3ebaf91{GoooFieldffd19ac5a7759ee3060bf3a50a37f6177f0970c00343fd0b09c17e9738ec2dcc: input2, GoooField30255b9c0ed5c552cc79a7345427c565ae7df33e1fb666c7c5a54753c93c5de9: false, GoooField0959ac3ccc504b2888464eb8dd343c42dc7076cd58e1700486b97e1c9d89f89a: 0}
}

//gooo:generated:end id="urn:gooo:assembly-feedback:describe" kind="activity"
