package main

//gooo:generated:start id="edited://activity/calculate" kind="activity"
func GoooComposedActivity0(input int64) int64 {
	return input * 2
}

//gooo:generated:end id="edited://activity/calculate" kind="activity"
