package main

//gooo:generated:start id="gooo://sourceedit/edit" kind="entity"
type GoooRecord23c75c499c3c7b668597c08978d3279f9689d886cc7f42be7439e2705491dab9 struct {
	GoooFieldadf0d17154d321ac73577482507f1f7986e7b8f40c9d6f53b6b831df99253276 bool   `json:"changed"`
	GoooFieldea7c7acb3f93cbd4f847c3ac86a86d5e346a24bc6e2d3f428020fdbd87f5ba40 string `json:"source"`
	GoooField193be97da84fe651fc1b06888a7b65415fb335f4b232fdaca6c0a2bb0f8929de int64  `json:"bytes"`
}

//gooo:generated:end id="gooo://sourceedit/edit" kind="entity"

//gooo:generated:start id="sourceedit://activity/splice" kind="activity"
func GoooComposedActivity0(input0 string, input1 string, input2 string, input3 string, input4 string) GoooRecord23c75c499c3c7b668597c08978d3279f9689d886cc7f42be7439e2705491dab9 {
	var output = GoooRecord23c75c499c3c7b668597c08978d3279f9689d886cc7f42be7439e2705491dab9{GoooFieldadf0d17154d321ac73577482507f1f7986e7b8f40c9d6f53b6b831df99253276: false, GoooFieldea7c7acb3f93cbd4f847c3ac86a86d5e346a24bc6e2d3f428020fdbd87f5ba40: input0, GoooField193be97da84fe651fc1b06888a7b65415fb335f4b232fdaca6c0a2bb0f8929de: 0}
	var matches = input0 == input1+input2+input3 && input2 != input4 && len(input1)+len(input4)+len(input3) <= 1024
	output.GoooFieldadf0d17154d321ac73577482507f1f7986e7b8f40c9d6f53b6b831df99253276 = (matches)
	if output.GoooFieldadf0d17154d321ac73577482507f1f7986e7b8f40c9d6f53b6b831df99253276 {
		output.GoooFieldea7c7acb3f93cbd4f847c3ac86a86d5e346a24bc6e2d3f428020fdbd87f5ba40 = (input1 + input4 + input3)
	}
	output.GoooField193be97da84fe651fc1b06888a7b65415fb335f4b232fdaca6c0a2bb0f8929de = int64(len(input0))
	return output
}

//gooo:generated:end id="sourceedit://activity/splice" kind="activity"
