package main

//gooo:generated:start id="urn:gooo:scalar-identity:label" kind="entity"
type GoooRecord82219763555cd04eb32dbc7cd5314ff2e892dbbb6561f57244f56f3b61f54566 struct {
	GoooFielde5b5e9fe960c249e87acdc607d573ec4d82eba5007e05ad0622985d2381ff553 string `json:"text"`
	GoooField8404fac68a6c7d9c24b9c61934d14419f5d39152034f5515cdd66992cfd489af bool   `json:"active"`
	GoooFieldea8a74800d4f3c87bbe45d347b3461213878b348dd114fe677e4ba66b32b3b0b int64  `json:"count"`
}

//gooo:generated:end id="urn:gooo:scalar-identity:label" kind="entity"

//gooo:generated:start id="urn:gooo:scalar-identity:describe" kind="activity"
func GoooComposedActivity0(input0 int64, input1 bool, input2 string) GoooRecord82219763555cd04eb32dbc7cd5314ff2e892dbbb6561f57244f56f3b61f54566 {
	var text = input2
	var active = input1 && input0 > 0
	if input1 && input0 > 0 {
		text = text + "!"
	}
	return GoooRecord82219763555cd04eb32dbc7cd5314ff2e892dbbb6561f57244f56f3b61f54566{GoooFielde5b5e9fe960c249e87acdc607d573ec4d82eba5007e05ad0622985d2381ff553: (text), GoooField8404fac68a6c7d9c24b9c61934d14419f5d39152034f5515cdd66992cfd489af: (active), GoooFieldea8a74800d4f3c87bbe45d347b3461213878b348dd114fe677e4ba66b32b3b0b: (input0)}
}

//gooo:generated:end id="urn:gooo:scalar-identity:describe" kind="activity"
