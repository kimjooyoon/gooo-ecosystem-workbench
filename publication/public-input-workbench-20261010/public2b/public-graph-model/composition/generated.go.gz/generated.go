package main

//gooo:generated:start id="graphchain://label" kind="entity"
type GoooRecord1d0a7da41fc34e6898baf1c42710864ef0a2fa4b752348d8c10bd35eb527dfef struct {
	GoooField643007a8a712186675db4b8334c58cec6a2f7f63aaa06d680211adaa5125ff24 string `json:"text"`
	GoooField87b90ba4f20c6b8e90052937df7127fd2e1c8e45d115be6b7452e9d7f895790e bool   `json:"active"`
	GoooField1ddbbded14a4e314792ef244230714bc1365d7166c47abe25b926bca623c90b2 int64  `json:"count"`
}

//gooo:generated:end id="graphchain://label" kind="entity"

//gooo:generated:start id="graphchain://activity/describe" kind="activity"
func GoooComposedActivity0(input0 int64, input1 bool, input2 string) GoooRecord1d0a7da41fc34e6898baf1c42710864ef0a2fa4b752348d8c10bd35eb527dfef {
	var text = input2
	var active = input1 && input0 > 0
	if active {
		text = text + "!"
	}
	return GoooRecord1d0a7da41fc34e6898baf1c42710864ef0a2fa4b752348d8c10bd35eb527dfef{GoooField643007a8a712186675db4b8334c58cec6a2f7f63aaa06d680211adaa5125ff24: input2, GoooField87b90ba4f20c6b8e90052937df7127fd2e1c8e45d115be6b7452e9d7f895790e: false, GoooField1ddbbded14a4e314792ef244230714bc1365d7166c47abe25b926bca623c90b2: (input0)}
}

//gooo:generated:end id="graphchain://activity/describe" kind="activity"

//gooo:generated:start id="graphchain://activity/extra" kind="activity"
func GoooComposedActivity1(input int64) int64 {
	return input
}

//gooo:generated:end id="graphchain://activity/extra" kind="activity"

//gooo:generated:start id="graphchain://activity/relabel" kind="activity"
func GoooComposedActivity2(input GoooRecord1d0a7da41fc34e6898baf1c42710864ef0a2fa4b752348d8c10bd35eb527dfef) GoooRecord1d0a7da41fc34e6898baf1c42710864ef0a2fa4b752348d8c10bd35eb527dfef {
	var text = input.GoooField643007a8a712186675db4b8334c58cec6a2f7f63aaa06d680211adaa5125ff24
	if input.GoooField87b90ba4f20c6b8e90052937df7127fd2e1c8e45d115be6b7452e9d7f895790e {
		text = "[" + text + "]"
	}
	return GoooRecord1d0a7da41fc34e6898baf1c42710864ef0a2fa4b752348d8c10bd35eb527dfef{GoooField643007a8a712186675db4b8334c58cec6a2f7f63aaa06d680211adaa5125ff24: input.GoooField643007a8a712186675db4b8334c58cec6a2f7f63aaa06d680211adaa5125ff24, GoooField87b90ba4f20c6b8e90052937df7127fd2e1c8e45d115be6b7452e9d7f895790e: false, GoooField1ddbbded14a4e314792ef244230714bc1365d7166c47abe25b926bca623c90b2: 0}
}

//gooo:generated:end id="graphchain://activity/relabel" kind="activity"

//gooo:generated:start id="graphchain://activity/main" kind="activity"
func GoooComposedActivity3(input0 GoooRecord1d0a7da41fc34e6898baf1c42710864ef0a2fa4b752348d8c10bd35eb527dfef, input1 int64) GoooRecord1d0a7da41fc34e6898baf1c42710864ef0a2fa4b752348d8c10bd35eb527dfef {
	return GoooRecord1d0a7da41fc34e6898baf1c42710864ef0a2fa4b752348d8c10bd35eb527dfef{GoooField643007a8a712186675db4b8334c58cec6a2f7f63aaa06d680211adaa5125ff24: input0.GoooField643007a8a712186675db4b8334c58cec6a2f7f63aaa06d680211adaa5125ff24, GoooField87b90ba4f20c6b8e90052937df7127fd2e1c8e45d115be6b7452e9d7f895790e: input0.GoooField87b90ba4f20c6b8e90052937df7127fd2e1c8e45d115be6b7452e9d7f895790e, GoooField1ddbbded14a4e314792ef244230714bc1365d7166c47abe25b926bca623c90b2: input0.GoooField1ddbbded14a4e314792ef244230714bc1365d7166c47abe25b926bca623c90b2 + input1}
}

//gooo:generated:end id="graphchain://activity/main" kind="activity"
