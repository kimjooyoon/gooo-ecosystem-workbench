package main

//gooo:generated:start id="mixedhole://parts" kind="entity"
type GoooRecord891d5b6abbeab24ef19d195e00fa3c82b5e1ffd07d7f6ba8c0fc439a3bc62cb6 struct {
	GoooFieldec2423711a6a44be62aa4659c717bc91491a0bf8b3d3a614e033fee2080c7cdf int64 `json:"first"`
	GoooField626cfd8be00abdf96f5e2c0a7b378104f5759c7bd49af4d4a00d82d9a47a5d51 int64 `json:"second"`
	GoooField9d7dd3075c5d8c775c712a919739de3e05c8e4ee824776bf3909e002ce777ead bool  `json:"ready"`
}

//gooo:generated:end id="mixedhole://parts" kind="entity"

//gooo:generated:start id="mixedhole://activity/main" kind="activity"
func GoooComposedActivity0(input int64) int64 {
	var n = GoooComposedActivity0Call0(input)
	var p = GoooComposedActivity0Call1(input)
	if n != -1 && input != 0 {
		return -1
	}
	if p.GoooField9d7dd3075c5d8c775c712a919739de3e05c8e4ee824776bf3909e002ce777ead {
		return p.GoooFieldec2423711a6a44be62aa4659c717bc91491a0bf8b3d3a614e033fee2080c7cdf + p.GoooField626cfd8be00abdf96f5e2c0a7b378104f5759c7bd49af4d4a00d82d9a47a5d51
	}
	return 0
}
func GoooComposedActivity0Call0(input int64) int64 {
	if input == 0 {
		return 0
	}
	return input / (-input)
}
func GoooComposedActivity0Call1(input int64) GoooRecord891d5b6abbeab24ef19d195e00fa3c82b5e1ffd07d7f6ba8c0fc439a3bc62cb6 {
	return GoooRecord891d5b6abbeab24ef19d195e00fa3c82b5e1ffd07d7f6ba8c0fc439a3bc62cb6{GoooFieldec2423711a6a44be62aa4659c717bc91491a0bf8b3d3a614e033fee2080c7cdf: (input * 2), GoooField626cfd8be00abdf96f5e2c0a7b378104f5759c7bd49af4d4a00d82d9a47a5d51: (input * 3), GoooField9d7dd3075c5d8c775c712a919739de3e05c8e4ee824776bf3909e002ce777ead: (input > 0)}
}

//gooo:generated:end id="mixedhole://activity/main" kind="activity"
