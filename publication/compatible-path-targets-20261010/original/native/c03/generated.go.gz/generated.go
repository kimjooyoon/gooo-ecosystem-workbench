package generated

func Choose(input int64) int64 {
	if int64(0) < input {
		return (int64(0) - input)
	} else {
		return input
	}
}
