package main
import("encoding/json";"fmt";"os";
c00 "example.invalid/gooo-observation/c00"
c01 "example.invalid/gooo-observation/c01"
c02 "example.invalid/gooo-observation/c02"
c03 "example.invalid/gooo-observation/c03"
c04 "example.invalid/gooo-observation/c04"
c05 "example.invalid/gooo-observation/c05"
c06 "example.invalid/gooo-observation/c06"
c07 "example.invalid/gooo-observation/c07"
)
type value struct { Value int64 `json:"value"`; Failure string `json:"failure,omitempty"` }
type row struct { Mask int `json:"mask"`; Values []value `json:"values"` }
func call(f func(int64) int64, input int64) (v value) {
    defer func(){ if p := recover(); p != nil { v.Failure = fmt.Sprint(p) } }()
    v.Value = f(input); return
}
func main(){ rows := []row{}
rows = append(rows, row{Mask:0, Values:[]value{call(c00.Choose, int64(-7)),call(c00.Choose, int64(-5)),call(c00.Choose, int64(-1)),call(c00.Choose, int64(0)),call(c00.Choose, int64(1)),call(c00.Choose, int64(3)),call(c00.Choose, int64(7)),call(c00.Choose, int64(9007199254740993)),call(c00.Choose, int64(-9007199254740993)),}})
rows = append(rows, row{Mask:1, Values:[]value{call(c01.Choose, int64(-7)),call(c01.Choose, int64(-5)),call(c01.Choose, int64(-1)),call(c01.Choose, int64(0)),call(c01.Choose, int64(1)),call(c01.Choose, int64(3)),call(c01.Choose, int64(7)),call(c01.Choose, int64(9007199254740993)),call(c01.Choose, int64(-9007199254740993)),}})
rows = append(rows, row{Mask:2, Values:[]value{call(c02.Choose, int64(-7)),call(c02.Choose, int64(-5)),call(c02.Choose, int64(-1)),call(c02.Choose, int64(0)),call(c02.Choose, int64(1)),call(c02.Choose, int64(3)),call(c02.Choose, int64(7)),call(c02.Choose, int64(9007199254740993)),call(c02.Choose, int64(-9007199254740993)),}})
rows = append(rows, row{Mask:3, Values:[]value{call(c03.Choose, int64(-7)),call(c03.Choose, int64(-5)),call(c03.Choose, int64(-1)),call(c03.Choose, int64(0)),call(c03.Choose, int64(1)),call(c03.Choose, int64(3)),call(c03.Choose, int64(7)),call(c03.Choose, int64(9007199254740993)),call(c03.Choose, int64(-9007199254740993)),}})
rows = append(rows, row{Mask:4, Values:[]value{call(c04.Choose, int64(-7)),call(c04.Choose, int64(-5)),call(c04.Choose, int64(-1)),call(c04.Choose, int64(0)),call(c04.Choose, int64(1)),call(c04.Choose, int64(3)),call(c04.Choose, int64(7)),call(c04.Choose, int64(9007199254740993)),call(c04.Choose, int64(-9007199254740993)),}})
rows = append(rows, row{Mask:5, Values:[]value{call(c05.Choose, int64(-7)),call(c05.Choose, int64(-5)),call(c05.Choose, int64(-1)),call(c05.Choose, int64(0)),call(c05.Choose, int64(1)),call(c05.Choose, int64(3)),call(c05.Choose, int64(7)),call(c05.Choose, int64(9007199254740993)),call(c05.Choose, int64(-9007199254740993)),}})
rows = append(rows, row{Mask:6, Values:[]value{call(c06.Choose, int64(-7)),call(c06.Choose, int64(-5)),call(c06.Choose, int64(-1)),call(c06.Choose, int64(0)),call(c06.Choose, int64(1)),call(c06.Choose, int64(3)),call(c06.Choose, int64(7)),call(c06.Choose, int64(9007199254740993)),call(c06.Choose, int64(-9007199254740993)),}})
rows = append(rows, row{Mask:7, Values:[]value{call(c07.Choose, int64(-7)),call(c07.Choose, int64(-5)),call(c07.Choose, int64(-1)),call(c07.Choose, int64(0)),call(c07.Choose, int64(1)),call(c07.Choose, int64(3)),call(c07.Choose, int64(7)),call(c07.Choose, int64(9007199254740993)),call(c07.Choose, int64(-9007199254740993)),}})
if err := json.NewEncoder(os.Stdout).Encode(rows); err != nil { panic(err) }
}