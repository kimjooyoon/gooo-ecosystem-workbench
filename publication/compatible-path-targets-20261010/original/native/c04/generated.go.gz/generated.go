package generated

func Choose(input int64) int64 {
	if input < int64(0) {
		return input
	} else {
		return (input - int64(0))
	}
}
