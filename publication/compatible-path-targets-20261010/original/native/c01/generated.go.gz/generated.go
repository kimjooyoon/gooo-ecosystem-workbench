package generated

func Choose(input int64) int64 {
	if input < int64(0) {
		return (int64(0) - input)
	} else {
		return input
	}
}
