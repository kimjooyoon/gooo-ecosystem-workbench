module example.invalid/gooo-observation

go 1.27.2
