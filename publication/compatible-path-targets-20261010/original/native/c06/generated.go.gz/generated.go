package generated

func Choose(input int64) int64 {
	if int64(0) < input {
		return input
	} else {
		return (input - int64(0))
	}
}
