package main

//gooo:generated:start id="charge://parts" kind="entity"
type GoooRecordd399723daf5f3995ae1fa6bf23e8e42d616891f19676e6737e4bb2416e79c86a struct {
	GoooField7fafb2d43b7060cea7e40b2fcfd077be568f685420ad212cbee69a93b649d38e int64 `json:"base"`
	GoooFieldf4a7c239426d6d316cbd0b82e384f513164918b188245778d1ff1923a9df49b1 int64 `json:"rebate"`
	GoooFieldd96097bcdf3745f9eb5b4811327eb0301e13fa429ffae5b68adbcce9321b40bb bool  `json:"apply"`
}

//gooo:generated:end id="charge://parts" kind="entity"

//gooo:generated:start id="charge://activity/main" kind="activity"
func GoooComposedActivity0(input int64) int64 {
	var parts = GoooComposedActivity0Call0(input)
	if parts.GoooFieldd96097bcdf3745f9eb5b4811327eb0301e13fa429ffae5b68adbcce9321b40bb {
		return parts.GoooField7fafb2d43b7060cea7e40b2fcfd077be568f685420ad212cbee69a93b649d38e - parts.GoooFieldf4a7c239426d6d316cbd0b82e384f513164918b188245778d1ff1923a9df49b1
	}
	return parts.GoooField7fafb2d43b7060cea7e40b2fcfd077be568f685420ad212cbee69a93b649d38e
}
func GoooComposedActivity0Call0(input int64) GoooRecordd399723daf5f3995ae1fa6bf23e8e42d616891f19676e6737e4bb2416e79c86a {
	return GoooRecordd399723daf5f3995ae1fa6bf23e8e42d616891f19676e6737e4bb2416e79c86a{GoooField7fafb2d43b7060cea7e40b2fcfd077be568f685420ad212cbee69a93b649d38e: (input * 12), GoooFieldf4a7c239426d6d316cbd0b82e384f513164918b188245778d1ff1923a9df49b1: input * 2, GoooFieldd96097bcdf3745f9eb5b4811327eb0301e13fa429ffae5b68adbcce9321b40bb: (input >= 50)}
}

//gooo:generated:end id="charge://activity/main" kind="activity"
