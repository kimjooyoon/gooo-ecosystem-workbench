package main

//gooo:generated:start id="caller-model://plan" kind="entity"
type GoooRecord056770d9c6c9b1a12c98375360d6ce7c6b8427f1bf3b3f57150c446a1e71904d struct {
	GoooFielde7738ca6f3aa54ceead537637b6a8a8bb3a8ec7678b37c4ad6d295206fb8ee51 int64 `json:"first"`
	GoooField7a41a58bf434300156e51aa2fc546ea05bf42f86ffa6bad145f112c819753caf int64 `json:"second"`
	GoooField9cd2951f40853cff8e27e366116d04358676f01b0181d279d2e3c966a8371838 bool  `json:"ready"`
}

//gooo:generated:end id="caller-model://plan" kind="entity"

//gooo:generated:start id="caller-model://activity/main" kind="activity"
func GoooComposedActivity0(input int64) int64 {
	var parts = GoooComposedActivity0Call0(input)
	if parts.GoooField9cd2951f40853cff8e27e366116d04358676f01b0181d279d2e3c966a8371838 {
		return parts.GoooFielde7738ca6f3aa54ceead537637b6a8a8bb3a8ec7678b37c4ad6d295206fb8ee51 + parts.GoooField7a41a58bf434300156e51aa2fc546ea05bf42f86ffa6bad145f112c819753caf
	}
	return 0
}
func GoooComposedActivity0Call0(input int64) GoooRecord056770d9c6c9b1a12c98375360d6ce7c6b8427f1bf3b3f57150c446a1e71904d {
	return GoooRecord056770d9c6c9b1a12c98375360d6ce7c6b8427f1bf3b3f57150c446a1e71904d{GoooFielde7738ca6f3aa54ceead537637b6a8a8bb3a8ec7678b37c4ad6d295206fb8ee51: (input * 2), GoooField7a41a58bf434300156e51aa2fc546ea05bf42f86ffa6bad145f112c819753caf: (input * 3), GoooField9cd2951f40853cff8e27e366116d04358676f01b0181d279d2e3c966a8371838: (input > 0)}
}

//gooo:generated:end id="caller-model://activity/main" kind="activity"
