package main

//gooo:generated:start id="division://result" kind="entity"
type GoooRecordfe6d6694a9b86679a3243c4de328d8718c85ffb4dc2abfe72193b7bf18933088 struct {
	GoooFieldc605d35f977b7602a0e631125fdcd4d4967baad217d069251998fc3573187b5f bool  `json:"valid"`
	GoooField8157c3a5a8fe93ffaf44734d2105347ff83bcb61baf0fe375af6dd48c094364b int64 `json:"quotient"`
	GoooField35076b29ebd58b7aed6a9f636afe76316ba05e1b04b7a781997d70c693045908 int64 `json:"remainder"`
}

//gooo:generated:end id="division://result" kind="entity"

//gooo:generated:start id="division://activity/divide" kind="activity"
func GoooComposedActivity0(input0 int64, input1 int64) GoooRecordfe6d6694a9b86679a3243c4de328d8718c85ffb4dc2abfe72193b7bf18933088 {
	var valid = input1 != 0
	var divisor = input1
	if !valid {
		divisor = 1
	}
	var quotient = input0 / divisor
	var remainder = input0 % divisor
	if !valid {
		quotient = 0
		remainder = 0
	}
	return GoooRecordfe6d6694a9b86679a3243c4de328d8718c85ffb4dc2abfe72193b7bf18933088{GoooFieldc605d35f977b7602a0e631125fdcd4d4967baad217d069251998fc3573187b5f: !valid, GoooField8157c3a5a8fe93ffaf44734d2105347ff83bcb61baf0fe375af6dd48c094364b: (quotient), GoooField35076b29ebd58b7aed6a9f636afe76316ba05e1b04b7a781997d70c693045908: (remainder)}
}

//gooo:generated:end id="division://activity/divide" kind="activity"
