package main

//gooo:generated:start id="gooo://filenames/info" kind="entity"
type GoooRecordbd50b3b91cef5934ebdbe0c38362e034c45eab4065855c82935c2efce46d5e16 struct {
	GoooField735b647803676a896c7ea1da241fe61b0e0fff2d610797fbf2b81820b3d88c96 bool   `json:"source"`
	GoooFieldc1fb11d9e60c1ba8c3d50479aec9d50fb97e547c96238bc78f0914588e265b2f string `json:"stem"`
	GoooFieldc6bc1be5103ff474e0e67ad2649e748a0524a783a885dc517b9d4d3d1714b4ef int64  `json:"bytes"`
}

//gooo:generated:end id="gooo://filenames/info" kind="entity"

//gooo:generated:start id="filenames://activity/classify" kind="activity"
func GoooComposedActivity0(input string) GoooRecordbd50b3b91cef5934ebdbe0c38362e034c45eab4065855c82935c2efce46d5e16 {
	var suffix = GoooComposedActivity0Call0(input, ".gooo")
	var visible = !GoooComposedActivity0Call1(input, ".")
	var stem = GoooComposedActivity0Call2(input, ".gooo")
	_ = stem
	var bytes = GoooComposedActivity0Call3(input)
	return GoooRecordbd50b3b91cef5934ebdbe0c38362e034c45eab4065855c82935c2efce46d5e16{GoooField735b647803676a896c7ea1da241fe61b0e0fff2d610797fbf2b81820b3d88c96: suffix || visible, GoooFieldc1fb11d9e60c1ba8c3d50479aec9d50fb97e547c96238bc78f0914588e265b2f: input, GoooFieldc6bc1be5103ff474e0e67ad2649e748a0524a783a885dc517b9d4d3d1714b4ef: (bytes)}
}
func GoooComposedActivity0Call0(input0 string, input1 string) bool {
	return len(input0) >= len(input1) && input0[len(input0)-len(input1):] == input1
}
func GoooComposedActivity0Call1(input0 string, input1 string) bool {
	return len(input0) >= len(input1) && input0[:len(input1)] == input1
}
func GoooComposedActivity0Call2(input0 string, input1 string) string {
	if GoooComposedActivity0Call0(input0, input1) {
		return input0[:len(input0)-len(input1)]
	}
	return input0
}
func GoooComposedActivity0Call3(input string) int64 {
	return int64(len(input))
}

//gooo:generated:end id="filenames://activity/classify" kind="activity"
