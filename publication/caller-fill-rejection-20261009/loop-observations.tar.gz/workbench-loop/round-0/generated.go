package main

//gooo:generated:start id="budgetplan://budget" kind="entity"
type GoooRecord1c79c5894e83ea4a40cd5eddb08f1943ed91fd373bfc581cfd09f4fac25f1441 struct {
	GoooFieldeb24407badfe3cff279730325a5c9323a3f41c7f0a7128ae226cf0bf952aab13 int64 `json:"next"`
	GoooFieldaf76a9fc1889ac4340ea8d2be7f2ae1d3c8934a7c30b9c704e8bcf416ab7c742 bool  `json:"exhausted"`
}

//gooo:generated:end id="budgetplan://budget" kind="entity"
//gooo:generated:start id="budgetplan://work" kind="entity"
type GoooRecorddd02ac9bb32310bfcac8431057575cfc31cc9d8aee5f15e35871225d20538364 struct {
	GoooField884d54b5a92c139ae7a174d7ed79e855272e511a04ca72d78729226d5063efd1 int64 `json:"used"`
	GoooField942c55e2b2b462d5a2dad8a5de77e35351f055c1305b6e485158631b1f2c6ced int64 `json:"limit"`
}

//gooo:generated:end id="budgetplan://work" kind="entity"

//gooo:generated:start id="budgetplan://activity/main" kind="activity"
func GoooComposedActivity0(input GoooRecorddd02ac9bb32310bfcac8431057575cfc31cc9d8aee5f15e35871225d20538364) int64 {
	var plan = GoooComposedActivity0Call0(input)
	if plan.GoooFieldaf76a9fc1889ac4340ea8d2be7f2ae1d3c8934a7c30b9c704e8bcf416ab7c742 {
		return -plan.GoooFieldeb24407badfe3cff279730325a5c9323a3f41c7f0a7128ae226cf0bf952aab13
	}
	return plan.GoooFieldeb24407badfe3cff279730325a5c9323a3f41c7f0a7128ae226cf0bf952aab13
}
func GoooComposedActivity0Call0(input GoooRecorddd02ac9bb32310bfcac8431057575cfc31cc9d8aee5f15e35871225d20538364) GoooRecord1c79c5894e83ea4a40cd5eddb08f1943ed91fd373bfc581cfd09f4fac25f1441 {
	var next = input.GoooField884d54b5a92c139ae7a174d7ed79e855272e511a04ca72d78729226d5063efd1 + 1
	var exhausted = (input.GoooField884d54b5a92c139ae7a174d7ed79e855272e511a04ca72d78729226d5063efd1 > input.GoooField942c55e2b2b462d5a2dad8a5de77e35351f055c1305b6e485158631b1f2c6ced)
	if exhausted {
		next = input.GoooField884d54b5a92c139ae7a174d7ed79e855272e511a04ca72d78729226d5063efd1
	}
	return GoooRecord1c79c5894e83ea4a40cd5eddb08f1943ed91fd373bfc581cfd09f4fac25f1441{GoooFieldeb24407badfe3cff279730325a5c9323a3f41c7f0a7128ae226cf0bf952aab13: next, GoooFieldaf76a9fc1889ac4340ea8d2be7f2ae1d3c8934a7c30b9c704e8bcf416ab7c742: exhausted}
}

//gooo:generated:end id="budgetplan://activity/main" kind="activity"
