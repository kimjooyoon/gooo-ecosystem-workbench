package main

import (
	"encoding/json"
	"os"
)

func main() {
	var in [][1]json.RawMessage
	if json.NewDecoder(os.Stdin).Decode(&in) != nil || len(in) > 128 {
		os.Exit(2)
	}
	out := make([][2]json.RawMessage, len(in))
	for c, row := range in {
		var input0 GoooRecord87d72e74fac75e9730fc060240305f4c0bde78bba89dc8ba3e98d5d60cf53783
		if json.Unmarshal(row[0], &input0) != nil {
			os.Exit(2)
		}
		v0 := GoooComposedActivity0(input0)
		out[c][0], _ = json.Marshal(v0)
		v1 := GoooComposedActivity1(v0)
		out[c][1], _ = json.Marshal(v1)
	}
	if json.NewEncoder(os.Stdout).Encode(out) != nil {
		os.Exit(3)
	}
}
