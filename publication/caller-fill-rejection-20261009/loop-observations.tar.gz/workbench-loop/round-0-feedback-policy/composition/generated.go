package main

//gooo:generated:start id="gooo://jointfeedback/decision" kind="entity"
type GoooRecord2e3f0bc3e1cce4e0b7fa30beda461f64d4a95bb4e678b395f410d077c1ea8c3d struct {
	GoooFieldd0f2cacd27bfcf480f2509bc1e0871dd266646346a71cd3e81264e6fbfc1c6fa bool   `json:"include"`
	GoooField987d12ae09db01def5b19ab25f079693010ec7dc5c1d887a99e4a8d88643fd5a string `json:"reason"`
}

//gooo:generated:end id="gooo://jointfeedback/decision" kind="entity"
//gooo:generated:start id="gooo://jointfeedback/observation" kind="entity"
type GoooRecord87d72e74fac75e9730fc060240305f4c0bde78bba89dc8ba3e98d5d60cf53783 struct {
	GoooField16905cd7d009240a2a72f4563ccf16126bbd0f378b3d966442fb63cbb3c305c8 int64 `json:"matched"`
	GoooFieldf4f6ccea636b0ef4061e331265f52aaada3eefed6c2b9abe29266884753a2575 int64 `json:"total"`
	GoooField544b4e9f68c6404e6642ac3de4dac03d02ea3d3954acecca0e08248b8167a406 bool  `json:"known"`
}

//gooo:generated:end id="gooo://jointfeedback/observation" kind="entity"

//gooo:generated:start id="jointfeedback://activity/observation-echo" kind="activity"
func GoooComposedActivity0(input GoooRecord87d72e74fac75e9730fc060240305f4c0bde78bba89dc8ba3e98d5d60cf53783) GoooRecord87d72e74fac75e9730fc060240305f4c0bde78bba89dc8ba3e98d5d60cf53783 {
	return input
}

//gooo:generated:end id="jointfeedback://activity/observation-echo" kind="activity"

//gooo:generated:start id="jointfeedback://activity/decide" kind="activity"
func GoooComposedActivity1(input GoooRecord87d72e74fac75e9730fc060240305f4c0bde78bba89dc8ba3e98d5d60cf53783) GoooRecord2e3f0bc3e1cce4e0b7fa30beda461f64d4a95bb4e678b395f410d077c1ea8c3d {
	if input.GoooField16905cd7d009240a2a72f4563ccf16126bbd0f378b3d966442fb63cbb3c305c8 < 0 || input.GoooFieldf4f6ccea636b0ef4061e331265f52aaada3eefed6c2b9abe29266884753a2575 < 0 || input.GoooField16905cd7d009240a2a72f4563ccf16126bbd0f378b3d966442fb63cbb3c305c8 > input.GoooFieldf4f6ccea636b0ef4061e331265f52aaada3eefed6c2b9abe29266884753a2575 {
		return GoooRecord2e3f0bc3e1cce4e0b7fa30beda461f64d4a95bb4e678b395f410d077c1ea8c3d{GoooFieldd0f2cacd27bfcf480f2509bc1e0871dd266646346a71cd3e81264e6fbfc1c6fa: false, GoooField987d12ae09db01def5b19ab25f079693010ec7dc5c1d887a99e4a8d88643fd5a: "invalid-observation"}
	}
	if input.GoooFieldf4f6ccea636b0ef4061e331265f52aaada3eefed6c2b9abe29266884753a2575 == 0 {
		return GoooRecord2e3f0bc3e1cce4e0b7fa30beda461f64d4a95bb4e678b395f410d077c1ea8c3d{GoooFieldd0f2cacd27bfcf480f2509bc1e0871dd266646346a71cd3e81264e6fbfc1c6fa: false, GoooField987d12ae09db01def5b19ab25f079693010ec7dc5c1d887a99e4a8d88643fd5a: "no-expectations"}
	}
	if input.GoooField544b4e9f68c6404e6642ac3de4dac03d02ea3d3954acecca0e08248b8167a406 {
		return GoooRecord2e3f0bc3e1cce4e0b7fa30beda461f64d4a95bb4e678b395f410d077c1ea8c3d{GoooFieldd0f2cacd27bfcf480f2509bc1e0871dd266646346a71cd3e81264e6fbfc1c6fa: false, GoooField987d12ae09db01def5b19ab25f079693010ec7dc5c1d887a99e4a8d88643fd5a: "already-retained-or-duplicate"}
	}
	if input.GoooField16905cd7d009240a2a72f4563ccf16126bbd0f378b3d966442fb63cbb3c305c8 < input.GoooFieldf4f6ccea636b0ef4061e331265f52aaada3eefed6c2b9abe29266884753a2575 {
		return GoooRecord2e3f0bc3e1cce4e0b7fa30beda461f64d4a95bb4e678b395f410d077c1ea8c3d{GoooFieldd0f2cacd27bfcf480f2509bc1e0871dd266646346a71cd3e81264e6fbfc1c6fa: true, GoooField987d12ae09db01def5b19ab25f079693010ec7dc5c1d887a99e4a8d88643fd5a: "counterexample"}
	}
	return GoooRecord2e3f0bc3e1cce4e0b7fa30beda461f64d4a95bb4e678b395f410d077c1ea8c3d{GoooFieldd0f2cacd27bfcf480f2509bc1e0871dd266646346a71cd3e81264e6fbfc1c6fa: false, GoooField987d12ae09db01def5b19ab25f079693010ec7dc5c1d887a99e4a8d88643fd5a: "matched"}
}

//gooo:generated:end id="jointfeedback://activity/decide" kind="activity"
