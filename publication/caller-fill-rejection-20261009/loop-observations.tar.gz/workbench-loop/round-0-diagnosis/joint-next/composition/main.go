package main

import (
	"encoding/json"
	"os"
)

func main() {
	var in [][1]json.RawMessage
	if json.NewDecoder(os.Stdin).Decode(&in) != nil || len(in) > 128 {
		os.Exit(2)
	}
	out := make([][2]json.RawMessage, len(in))
	for c, row := range in {
		var input0 GoooRecord09df6a2147ed3bde000c10a75a077c5c6dd5b86e45676824e1a11f258545b1e3
		if json.Unmarshal(row[0], &input0) != nil {
			os.Exit(2)
		}
		v0 := GoooComposedActivity0(input0)
		out[c][0], _ = json.Marshal(v0)
		v1 := GoooComposedActivity1(v0)
		out[c][1], _ = json.Marshal(v1)
	}
	if json.NewEncoder(os.Stdout).Encode(out) != nil {
		os.Exit(3)
	}
}
